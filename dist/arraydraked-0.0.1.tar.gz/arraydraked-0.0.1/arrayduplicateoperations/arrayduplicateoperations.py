def arraycheck(arr):
	if(len(arr) == len(set(arr))):
		return True
	else:
		return False

