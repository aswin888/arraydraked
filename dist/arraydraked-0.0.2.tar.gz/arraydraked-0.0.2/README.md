# arraydraked

This is a python package which can be used to check if an array has any duplicated elements. To install the package run the following command.

    pip install arraydraked

# How to use

The methods are as follows

    arraycheck()
    dictCreator()
 The arguments to the functions are arrays. The `arraycheck()` returns are value false if there is any duplicate values.
 The `dictCreator()` returns a dictionary with  the keys as the elements and the values as the mode of each element.

> Follow @AswinSankar@18 on ![enter image description here](http://i.imgur.com/tXSoThF.png%20%28twitter%20icon%20with%20padding%29) 